<?php
session_start();
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="E-Dino es una plataforma de aprendizaje personalizada. Aprende a tu ritmo con nuestros planes de estudio flexibles.">
    <title>E-Dino</title>
    <link rel="stylesheet" href="../assets/css/style-index.css">
    <link rel="icon" href="../assets/images/logo.ico">
    <script type="module" src="https://unpkg.com/@splinetool/viewer@1.9.21/build/spline-viewer.js"></script>
</head>
<body>
    <?php
    include '../includes/header.php';
    include '../includes/navbar.php';
    ?>

    <main>
        <section class="hero fade-in">
            <h1>E-Dino</h1>
            <p>Aprende a tu modo... A tu ritmo.</p>
            <?php if (isset($_SESSION['user_id'])): ?>
                <button id="hero-classes-btn" onclick="window.location.href='dashboard.php'">Ir a mis clases</button>
            <?php else: ?>
                <button id="hero-register-btn" onclick="window.location.href='register.php'">Regístrate</button>
            <?php endif; ?>
        </section>

        <section class="hero fade-int">

        </section>

        <section class="hero fullscreen">
            <img src="../assets/images/wallper_index_2.svg" alt="Descripción de la imagen">
            <h1>Súmate a Nosotros</h1>
            <p>y sé parte del cambio más significativo de la educación.</p>
        </section>

        <section class="hero fade-ints">

        </section>


    </main>

    <?php include '../includes/footer.php'; ?>
    <script src="../assets/js/scripts.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                    }
                });
            }, { threshold: 0.1 });

            document.querySelectorAll('.fade-in').forEach(section => {
                observer.observe(section);
            });
        });
    </script>
</body>
</html>
