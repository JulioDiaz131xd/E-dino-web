<footer class="footer">
    <div class="footer-container">
        <p>© 2024 E-Dino. Todos los derechos reservados.</p>
        <div class="social-icons">
        </div>
    </div>
</footer>
